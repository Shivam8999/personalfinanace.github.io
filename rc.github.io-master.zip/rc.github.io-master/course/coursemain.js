 // var url=window.location.search;
// var search_param=new URLSearchParams(url);
// var param1=search_param.get("course");
// var param2=search_param.get("page");
//
// // console.log(param1)
// if (param1 && param2){
//   console.log("true")
//       }   else   {
//         load_tutebox("/new_website/course/html_5/html_intro.html");
//         opencontent("#html_content","#html","#html .arrow","/new_website/course/html_5/listview.html");
//       }


 function opencontent(div,button,arrow,element,height){
    var content=document.querySelector(div)
    content.style.height=height+"px"
    // content.style.display="table"
    // content.innerHTML="hello <br>dshbfjh <br>dbj<br> <br>fa<br>sj jg<br>fjs <br>jgd<br>fdj<br> jdgj <br> jas<br>dbf <br>dsm<br>ndf<br>bu"
    $(div).load(element)
    var botton=document.querySelector(button)
    botton.setAttribute("onclick","closecontent('"+div+"','"+button+"','"+arrow+"','"+element+"','"+height+"')")
    var arrow=document.querySelector(arrow)
    arrow.innerHTML="&#8743;"
}

function closecontent(div,button,arrow,element,height){
  var content=document.querySelector(div)
  content.style.height="0px"
  // content.style.display="block";
  content.innerHTML=""
  var botton=document.querySelector(button)
  botton.setAttribute("onclick","opencontent('"+div+"','"+button+"','"+arrow+"','"+element+"','"+height+"')")
  var arrow=document.querySelector(arrow)
  arrow.innerHTML="&#8744;"
}

function load_tutebox(element){
  //the element is the content what we want to load in load_tutebox
   $("#tutebox").load(element)
}

// window.onload=()=> {
//   if (window.innerWidth<1100 && window.innerWidth>700){
//     var width=window.innerWidth
//     var height=window.innerHeight
//     console.log(window.innerHeight-80)
//   // document.querySelector("#tutebox").style.width=width-261+"px"
//   document.querySelector("#sidenavcourse").style.height=height-80+"px"
//   // document.querySelector("#tutebox").style.height=height-90+"px"
//   }
// }
//
// window.onresize=()=>{
//   if (window.innerWidth<1100 && window.innerWidth>700){
//     var width=window.innerWidth
//     var height=window.innerHeight
//     console.log(window.innerWidth)
//   // document.querySelector("#tutebox").style.width=width-277+"px"
//   document.querySelector("#sidenavcourse").style.height=height-80+"px"
//   document.querySelector("#tutebox").style.height=height-90+"px"
// }
// }
// document.onload(document.write("hello"))
// function content(id){
//   document.querySelector(id).style.height="200px"
// }
