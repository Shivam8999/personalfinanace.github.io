<?php

$user = "subscriber";
$pass="none";
$servername = "localhost";
$database = "subscribe";
$database_movies="movies";

function create_div(){
  $added = $tens+$unit;
    echo "const post=document.createElement('div')
    post.className='post'
    document.querySelector('#newpos').append(post)
    post.innerHTML='hello'";
    // post.innerHTML='<a href=/new_website/movies/?varvideo=".$vab[$num][2]."&varname=".$vab[$num][3]."><img src=".$vab[$num][1]." height=100% width=100%><img></a>'";
  };

 ?>
