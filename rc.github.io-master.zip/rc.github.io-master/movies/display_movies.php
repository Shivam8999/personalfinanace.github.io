<?php

$var=$_GET["varo"];
// $varaa=(str);
$varoo=(int)$var;//this will convert var into integer because the it is taken as string
// var_dump($varoo);
error_reporting(0);//this will stop server from displaying error's exact information
include 'conn_info.php';
$varia=1;
$vab=array();
$connect=new mysqli($servername,$user,$pass,$database_movies);
if($connect->connect_error){
  die(" failed to connect to server please refresh the page or try again after some time ".$connect->error);
}

$movie_icon="SELECT * FROM movie";
$result=$connect->query($movie_icon);
while($row=$result->fetch_assoc()){
  $new_array=array();
      foreach ($row as $element) {
        array_push($new_array,$element);
          }
  array_push($vab,$new_array);

};
$imagelink= $vab[$varoo][1];
$videolink=$vab[$varoo][2];
$videoname=$vab[$varoo][3];
echo "<a href=/new_website/movies/index.html?varvideo=$videolink&varname=$videoname><div id=img><img src=$imagelink></img></div><div id=cont><h1>$videoname</h1></div></a>";
// echo $vab[$varoo][2];


 ?>
