<?php
$password=23618;
$username="commenter";
$server="localhost";
$database="users";
$table="user";
 ?>
