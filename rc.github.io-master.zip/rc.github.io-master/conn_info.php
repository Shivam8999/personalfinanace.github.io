<?php

$user = "subscriber";
$pass="none";
$servername = "localhost";
$database = "subscribe";
$database_movies="movies"



 ?>
