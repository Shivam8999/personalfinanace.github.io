$(document).ready(function(){
$("#content").load("courseframe.html")  })

function loadcourse(){
  $("#content").load("courseframe.html")
}
function loadmovies(){
  $("#content").load("moviesframe.html")
}
function loadnews(){
  $("#content").load("newsframe.html")
}
function loadtop(){
  $("#content").load("top10frame.html")
}

function closenav(){
document.getElementById("sidemenu").style.width="0px"
document.querySelector("#sidemenu").innerHTML=""
}

function opennav(){
  document.getElementById("sidemenu").style.width="210px"
  $("#sidemenu").load("/new_website/global/head_sidemenu.html .sidemenu a,button")

}

function askm(){
  $(".askmail").load("/new_website/alert_prompt/askmailid.html") }
